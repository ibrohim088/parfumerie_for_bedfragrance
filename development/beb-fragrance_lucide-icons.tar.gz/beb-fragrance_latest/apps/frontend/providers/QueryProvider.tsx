'use client';
import { ReactQueryProvider } from './ReactQueryProvider';
export default function QueryProvider({ children }: { children: React.ReactNode }) {
  return <ReactQueryProvider>{children}</ReactQueryProvider>;
}